package com.onedev.pokedex.core.data.source.remote.response

data class DataStat(
    val name: String,
    val url: String
)