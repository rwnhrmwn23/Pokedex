package com.onedev.pokedex.core.data.source.remote.response

data class DataPokemonType(
    val slot: Int,
    val type: DataType
)