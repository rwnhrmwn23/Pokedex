package com.onedev.pokedex.utils

import com.onedev.pokedex.BuildConfig

object Constant {

    const val BASE_URL = BuildConfig.BASE_URL
    const val HOSTNAME = BuildConfig.HOSTNAME
    const val HOSTNAME_PINS1 = BuildConfig.HOSTNAME_PINS1
    const val DATABASE_NAME = BuildConfig.DATABASE_NAME

}