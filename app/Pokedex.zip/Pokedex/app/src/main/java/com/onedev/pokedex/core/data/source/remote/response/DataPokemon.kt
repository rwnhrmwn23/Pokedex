package com.onedev.pokedex.core.data.source.remote.response

data class DataPokemon(
    val name: String,
    val url: String
)