package com.onedev.pokedex.core.data.source.remote.response

data class DataType(
    val name: String,
    val url: String
)