# Pokedex
Pokedex is the result of my learning about the android architecture component that uses the MVVM design pattern
